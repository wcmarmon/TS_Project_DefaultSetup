/*
* index.ts
* 
* This source file will implement [TODO – add in description]
*/
// TODO: add in import statements
/*
* function main();
* 
* This is the mainline code for our project. This code will
* perform the following work:
* TODO – add in description
*/
function main()
{
    console.log ("Hello project");
    // TODO: our project code goes here
}
main(); // execute main function