/*
 * index.ts
 *
 * This source file will implement [TODO – add in description]
 */
// TODO: add in import statements
/*
 * function main();
 *
 * This is the mainline code for our project. This code will
 * perform the following work:
 * TODO – add in description
 */

import express, { Request, Response, NextFunction } from "express";

function main() {
  const port: number = 4000;
  // create an express application
  const app: express.Application = express();  
  // middleware for our application
  app.use((req: Request, res: Response, next: NextFunction) => {
    // our custom processing on each request to our application - this outputs the request to the console
    console.log(`${req.method} ${req.path}`);
    // continue default processing of the request
    next();
  });
  // register a route handler for a HTTP GET request
  app.get("/", (req: Request, res: Response) => {
    res.send("Welcome to our first TypeScript REST API App!");
  });
  // create a router for our API
  const apiRouter = express.Router();
  // middleware for our API router
  apiRouter.use((req: Request, res: Response, next: NextFunction) => {
    // our custom processing on each request to our API - currently just console logging
    console.log("API router specific middleware!");
    // continue default processing
    next();
  });
  // register a route handler for a HTTP GET request
  apiRouter.get("/testapi", (req: Request, res: Response) => {
    // our custom processing on each request to the /testapi endpoint
    console.log("In our test API handler ");
    // send a response
    res.send("test API endpoint reached!");
  });
  // register our API router - this will be mounted at /api - i.e. http://localhost:4000/api
  app.use(apiRouter);
  // start our application
  app.listen(port, () => {
    console.log(`Welcome to Team 2's REST API (on port ${port})`);
  });
}
main(); // execute main function
